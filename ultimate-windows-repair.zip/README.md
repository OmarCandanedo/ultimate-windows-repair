# Ultimate Windows Repair & Optimization Suite

**La navaja suiza definitiva para el mantenimiento de equipos Windows en entornos corporativos y de oficina.**

Esta herramienta en un solo archivo batch (`.bat`) integra decenas de utilidades de diagnóstico, reparación y optimización, seleccionadas y mejoradas a partir de scripts clásicos, con un enfoque **no destructivo** y **respetuoso con los datos del usuario y las aplicaciones de trabajo**.

## 🎯 ¿Para quién es?

- Técnicos de soporte TI que necesitan una solución rápida y completa.
- Usuarios avanzados que desean mantener su equipo en óptimas condiciones.
- Empresas que utilizan software de gestión como **Contpaq**, **CAAAREM3**, **Adsys**, o multifuncionales **Sharp** / **Brother** (respetando el puerto 21 FTP).

## ✨ Características destacadas

- **🛡️ 100% No destructivo**: Lista de carpetas y procesos protegidos (Descargas, Documentos, Dropbox, OneDrive, Python, Java, Contpaq, etc.). No toca unidades de red.
- **🧠 Reparación inteligente por eventos**: Analiza los últimos 55 errores del Visor de Windows y aplica correcciones automáticas (red, impresión, disco, Windows Update).
- **📊 Progreso visual en tareas largas**: Barras de progreso para SFC y DISM (¡adiós a la incertidumbre!).
- **⚙️ Más de 50 funciones organizadas en menú**:
  - Reparaciones básicas (rápida, completa, red, impresoras, navegadores, Windows Update).
  - Optimizaciones (servicios, WiFi, espacio en disco, inicio, modos Express/Ligera/Offline/Máxima).
  - Diagnóstico y mantenimiento (puntuación de salud, puntos de restauración, chkdsk, logs).
  - Herramientas avanzadas (hard reset Chrome, optimizaciones para Java/Python/Node.js, bloqueo de bloatware, Winget).
  - Aplicaciones de oficina (CAAAREM3, CONTPAQ, Thunderbird, configuración Sharp).
  - Red avanzada y BSOD (Red Max Agresiva, Firewall Hardening, GPU Tweaks, diagnóstico y reparación BSOD).
  - Funciones especiales (modo solo lectura, backup/restore, desactivar grabadores, activador educativo).
- **🔐 Seguridad y transparencia**: Backup automático antes de cambios agresivos, logs detallados y posibilidad de restaurar configuraciones.

## 🚀 Uso básico

1. Ejecuta el archivo como **Administrador**.
2. Navega por el menú escribiendo el número de la opción deseada.
3. Sigue las instrucciones en pantalla.

> **Recomendación inicial**: Prueba la **opción 26 (Reparación inteligente por eventos)** para una corrección automática basada en los errores recientes de tu sistema.

## 📁 Estructura del proyecto

- `ultimate_windows_repair.bat` – Script principal.
- `logs/` – Carpeta donde se guardan los registros de ejecución (se crea automáticamente).
- `backups/` – Carpeta con backups de configuración antes de cambios agresivos.

## 📜 Licencia

Este proyecto está bajo la licencia MIT. Eres libre de usarlo, modificarlo y distribuirlo, siempre manteniendo el crédito correspondiente.

---

**¡Repara, optimiza y mantén tu Windows como un profesional!** Si encuentras útil esta herramienta, no olvides dejar una estrella ⭐ en GitHub.